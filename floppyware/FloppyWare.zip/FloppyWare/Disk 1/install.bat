@echo off
cls
echo Installing FloppyWare...
echo|set /p="0%%"
echo|set /p="..."
timeout 1 > NUL
echo|set /p="10%%"
echo|set /p="..."
timeout 1 > NUL
echo|set /p="20%%"
echo|set /p="..."
timeout 1 > NUL
echo|set /p="30%%"
echo|set /p="..."
timeout 1 > NUL
echo|set /p="40%%"
echo|set /p="..."
timeout 1 > NUL
echo|set /p="50%%"
echo|set /p="..."
timeout 1 > NUL
echo|set /p="60%%"
echo|set /p="..."
timeout 1 > NUL
echo|set /p="70%%"
echo|set /p="..."
timeout 1 > NUL
echo ERROR
timeout 1 > NUL
echo FATAL ERROR: %USERNAME% hasn't appreciated the music thoroughly!
timeout 3 > NUL
echo DELETING ENTIRE OS...
timeout 2 > NUL
tree C:/Windows
echo INFO: JK GET TROLLED
pause