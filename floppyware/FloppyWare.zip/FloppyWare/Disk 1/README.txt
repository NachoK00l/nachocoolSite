Thank you for buying FloppyWare Floppy Edition! Please run FloppyWare Main Menu for the most optimal experience.
Press "Info" on the main menu for more info.